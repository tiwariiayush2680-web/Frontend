function Sidebar() {
  return (
    <aside className="w-56 bg-blue-950 text-white p-4">
      <h2 className="text-lg font-semibold mb-4">NIRIKSHAN</h2>
      <nav className="flex flex-col gap-2 text-sm">
        <a href="#" className="hover:underline">Dashboard</a>
        <a href="#" className="hover:underline">Inspections</a>
        <a href="#" className="hover:underline">Compliance Reports</a>
        <a href="#" className="hover:underline">Settings</a>
      </nav>
    </aside>
  )
}

export default Sidebar
