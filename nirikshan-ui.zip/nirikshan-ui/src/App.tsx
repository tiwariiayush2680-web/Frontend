import Sidebar from './Sidebar.tsx'

function App() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-6">
        <h1 className="text-2xl font-bold text-blue-900">
          NIRIKSHAN — Legal Metrology Inspection & Compliance Platform
        </h1>
        <p className="mt-2 text-gray-600">
          Project scaffold is running. Start building your app here.
        </p>
      </main>
    </div>
  )
}

export default App
